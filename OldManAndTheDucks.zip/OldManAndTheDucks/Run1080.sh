java -jar OldManAndTheDucks.jar 1920 1080 true
